clc;
clear;
close all;
%% Soal(1) : 
% Load data from the provided MAT file
load('Data.mat');

% Extract frequency (omega), magnitude, and phase from the data structure
omega = Data.omega;       % Frequency (rad/s)
magnitude = Data.magnitude; % Magnitude of frequency response
phase = Data.phase;       % Phase of frequency response (radians)

figure;
% Plot the magnitude (in decibels)
subplot(2,1,1);
semilogx(omega, 20*log10(magnitude)); % Convert magnitude to decibels
grid on;
title('Bode Diagram - Magnitude');
xlabel('Frequency (rad/s)');
ylabel('Magnitude (dB)');

% Plot the phase (in degrees)
subplot(2,1,2);
semilogx(omega, phase); 
grid on;
title('Bode Diagram - Phase');
xlabel('Frequency (rad/s)');
ylabel('Phase (degrees)');
%% Soal(2) :
% --- Determine System Type ---
% Calculate the slope of the magnitude plot at low frequencies
low_freq_index = omega < 1; % Low frequency range (below 1 rad/s)
low_freq_slope = (20*log10(magnitude(find(low_freq_index,1,'last'))) - ...
                  20*log10(magnitude(1))) / ...
                  (log10(omega(find(low_freq_index,1,'last'))) - log10(omega(1)));

% Classify system type based on slope
if abs(low_freq_slope + 20) < 5
    system_type = 'Type 1';
elseif abs(low_freq_slope) < 5
    system_type = 'Type 0';
elseif abs(low_freq_slope + 40) < 5
    system_type = 'Type 2';
else
    system_type = 'Unknown Type';
end

% --- Determine System Order ---
% Calculate the slope of the magnitude plot at high frequencies
high_freq_index = omega > 10; % High frequency range (above 10 rad/s)
high_freq_slope = (20*log10(magnitude(end)) - ...
                   20*log10(magnitude(find(high_freq_index,1,'first')))) / ...
                   (log10(omega(end)) - log10(omega(find(high_freq_index,1,'first'))));

% Estimate the system order based on high frequency slope
system_order = round(-high_freq_slope / 20);

% --- Calculate Time Delay ---
% Approximate delay using phase at high frequency
high_freq_phase = phase(end); % Phase at highest frequency (radians)
time_delay = -deg2rad(high_freq_phase) / omega(end); % Delay in seconds

% --- Check for Minimum Phase ---
% Minimum phase systems have all phase > -180 degrees
is_minimum_phase = all(rad2deg(phase) > -180);

% --- Display Results ---
fprintf('System Type: %s\n', system_type);
fprintf('System Order: %d\n', system_order);
fprintf('Time Delay: %.4f seconds\n', time_delay);
fprintf('Is Minimum Phase: %s\n', string(is_minimum_phase));
%% Soal(3) :
% Define the frequency response data
H = magnitude .* exp(1j * deg2rad(phase)); % Convert magnitude and phase to complex numbers

% Estimate a transfer function model
data = frd(H, omega); % Create frequency response data object

% Define desired order for the system
order_numerator = 1; % Numerator order
order_denominator = 3; % Denominator order

% Estimate the transfer function
sys = tfest(data, order_denominator, order_numerator);

% Display the transfer function
disp('Estimated Transfer Function:');
disp(sys);

% Plot the Bode plot of the estimated system
figure;
bode(sys);
grid on;
title('Bode Plot of Estimated System');
%disp(tf1);
%% Soal(4) :
% Extract the denominator of the transfer function
sys_tf = tf(sys); % Convert sys to a transfer function
denominator_coeffs = sys_tf.Denominator{1}; % Coefficients of the characteristic equation

% Check stability using the Routh-Hurwitz criterion
[rh_table, stability] = routh_hurwitz(denominator_coeffs);

% Display the Routh table
disp('Routh-Hurwitz Table:');
disp(rh_table);

% Display stability result
if stability
    disp('The system is stable.');
else
    disp('The system is unstable.');
end

%% Soal(5) :
% Convert the system to a transfer function
sys_tf = tf(sys); % Convert sys to tf type if it is not already

% Plot the root locus
figure;
rlocus(sys_tf); % Generate the root locus plot
grid on;
hold on;
rlocus(-sys_tf,'--');
hold off;
title('Root Locus of the System');
xlabel('Real Axis');
ylabel('Imaginary Axis');

Kp = 1;
Ki = +10; %Ki = -10
C_PI = tf([Kp, Ki], [1,0]); % C(s) = (Kp*s + Ki) / s
sys_tf2 = C_PI * sys_tf;
figure;
rlocus(sys_tf2);
grid on;
hold on;
rlocus(-sys_tf2,'--');
hold off;

Kp = 1;
Kd = 10;
C_PD = tf([Kd, Kp], 1); % C(s) = Kd*s + Kp
sys_tf3 = C_PD * sys_tf;
figure;
rlocus(sys_tf3);
grid on;
hold on;
rlocus(-sys_tf3,'--');
hold off;
%% Soal(6) :
s = tf('s'); % Define the Laplace variable
G = 0.1 / (s^2 + 0.9*s + 9); % Define the transfer function

% PID controller design
Kp = 454.4931; % Proportional gain (to be tuned)
Ki = 573.2218; % Integral gain (to be tuned)
Kd = 180.3868; % Derivative gain (to be tuned)
PID_controller = pid(Kp, Ki, Kd);

% Closed-loop system
closed_loop_sys = feedback(PID_controller * G, 1);

% Open-loop step response (without controller)
figure;
step(G);
grid on;
title('Open-Loop Step Response (Without Controller)');
info = stepinfo(G);
overshoot1 = info.Overshoot;
settling_time1 = info.SettlingTime;
disp(overshoot1);
disp(settling_time1);

% Closed-loop step response (with controller)
figure;
step(closed_loop_sys);
grid on;
title('Closed-Loop Step Response (With Controller)');
info = stepinfo(closed_loop_sys);
overshoot2 = info.Overshoot;
settling_time2 = info.SettlingTime;
disp(overshoot2);
disp(settling_time2);

% Use MATLAB PID tuner
pidTuner(G, 'PID');

%another method
figure;
bode(G);
margin(G);

figure;
bode(85.49*G);
margin(85.49*G);

figure;
bode((85.49*(0.45*s+1))/(0.09*s+1)*G);
margin((85.49*(0.45*s+1))/(0.09*s+1)*G);

figure;
step((85.49*(0.45*s+1))/(0.09*s+1)*G);

figure;
bode((1*(1.2*s+1))/(2.6*s+1)*(85.49*(0.45*s+1))/(0.09*s+1)*G);
margin((1*(1.2*s+1))/(2.6*s+1)*(85.49*(0.45*s+1))/(0.09*s+1)*G);

figure;
step((1*(1.2*s+1))/(2.6*s+1)*(85.49*(0.45*s+1))/(0.09*s+1)*G);
%% Soal(7.1) :
% Define PI controller parameters
Kp = -0.52284; % Proportional gain
Ki = -0.044521; % Integral gain for Kv = 60
PI_controller = pid(Kp, Ki); % Define PI controller

% Closed-loop system
closed_loop_sys = feedback(PI_controller * sys, 1);

% Plot ramp response
t = 0:1:100; % Time vector
ramp_input = t; % Ramp input
[y, t_out] = lsim(closed_loop_sys, ramp_input, t); % Simulate the system response

figure;
plot(t_out, ramp_input, 'r--', 'LineWidth', 1.5); % Reference ramp input
hold on;
plot(t_out, y, 'b', 'LineWidth', 1.5); % System response
grid on;
title('Ramp Response of the Closed-Loop System');
xlabel('Time (seconds)');
ylabel('Response');
legend('Ramp Input', 'System Output');

pidTuner(sys, 'PI');
%% Soal(7.2) :
s = tf('s'); % Laplace variable
G = (0.1 * (s - 2)) / (s * (s^2 + 0.9 * s + 9)); % Original system

% PID controller design
Kp = 3330890.5628; % Proportional gain (to be tuned)
Ki = 96819068.1663; % Integral gain (to be tuned)
Kd = 22933.1374; % Derivative gain (to be tuned)
PID_controller = pid(Kp, Ki, Kd); % Define the PID controller

% Closed-loop system
closed_loop_sys = feedback(PID_controller * G, 1);

% Step response
figure;
step(closed_loop_sys);
grid on;
title('Step Response of the Closed-Loop System');
xlabel('Time (seconds)');
ylabel('Amplitude');

% Ramp response
t = 0:0.1:50; % Time vector
ramp_input = t; % Ramp input
[y, t_out] = lsim(closed_loop_sys, ramp_input, t); % Simulate ramp response

% Plot ramp response
figure;
plot(t_out, ramp_input, 'r--', 'LineWidth', 1.5); % Reference ramp input
hold on;
plot(t_out, y, 'b', 'LineWidth', 1.5); % System output
grid on;
title('Ramp Response of the Closed-Loop System');
xlabel('Time (seconds)');
ylabel('Amplitude');
legend('Ramp Input', 'System Output');

pidTuner(G, 'PID');

%another methode
Td=(-0.5*(s-2))/((s+1)^3);
Sd=(s^3+3*s^2+3.5*s)/((s+1)^3);
Cs = Td/(Sd*sys);
gain=1.15;
LG= gain *Cs*sys;
CL=feedback(LG,1);
figure
step(CL);
information=stepinfo(CL);
undershoot=information.Undershoot;
disp(undershoot);
ts=information.SettlingTime;
disp(ts);
figure
step(tf(1,[1,0])*CL);
