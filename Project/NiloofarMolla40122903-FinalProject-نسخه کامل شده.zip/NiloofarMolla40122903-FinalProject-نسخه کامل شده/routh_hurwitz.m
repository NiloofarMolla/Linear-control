function [rh_table, stability] = routh_hurwitz(coeffs)
    n = length(coeffs);
    rh_table = zeros(n, ceil(n/2));
    rh_table(1, :) = coeffs(1:2:end); % Odd-index coefficients
    rh_table(2, 1:length(coeffs(2:2:end))) = coeffs(2:2:end); % Even-index coefficients
    
    for i = 3:n
        for j = 1:size(rh_table, 2)-1
            if rh_table(i-1, 1) == 0
                rh_table(i-1, 1) = 1e-6; % Small value to prevent division by zero
            end
            rh_table(i, j) = - (rh_table(i-1, 1) * rh_table(i-2, j+1) - rh_table(i-2, 1) * rh_table(i-1, j+1)) / rh_table(i-1, 1);
        end
    end
    
    stability = all(rh_table(:, 1) > 0); % Check positivity of the first column
end
